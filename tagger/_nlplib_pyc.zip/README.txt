The program MakeLex.py only needs to be run if you want to change
the lexicon entries in the file lexicon.txt. The file pickledlexicon 
is created by the MakeLex.py program.

There is a short Main test function at the bottom of the file
NLPlib.py that uses the tokenizer and tagger.

This software is licensed under the GPL (www.fsf.org). You can
purchase an alternative license (LGPL) to use this software in
non-GPL commercial products.

Please see: http://www.fsf.org/licensing/licenses/index_html
for details and contact me at: contact@jasonwiener.com
